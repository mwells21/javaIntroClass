// Create interface Rotatable with rotateObject method 
public interface Rotatable
{
  void rotateObject();
}
