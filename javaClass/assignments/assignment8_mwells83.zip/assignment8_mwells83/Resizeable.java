// Create interface Resizeable with resizeObject method 
public interface Resizeable
{
  void resizeObject();
}
