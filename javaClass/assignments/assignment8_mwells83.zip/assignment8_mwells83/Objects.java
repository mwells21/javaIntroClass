// Create abstract class Objects
//
// implements:
// Resizeable
// Sounds
// Rotatable
// Drawable
//
// Currently Extended By Animal and Vehicle
public abstract class Objects implements Resizeable, Sounds, Rotatable, Drawable
{

}
