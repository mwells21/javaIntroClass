// Create interface Drawable with drawObject method 
public interface Drawable
{
  void drawObject();
}
