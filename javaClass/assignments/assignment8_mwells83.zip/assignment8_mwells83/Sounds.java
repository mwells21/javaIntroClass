// Create interface Sounds with playSounds method 
public interface Sounds
{
  void playSounds();
}
