//     Michael Wells
//    EN.605.201.83.SU19
//    Assignment 1
//    06/02/19
//

public class JavaIntroPrint
{
  public static void main( String [] args )
  {
      System.out.println("    J    A   V     V    A");
      System.out.println("    J   A A   V   V    A A");
      System.out.println("J   J  AAAAA   V V    AAAAA");
      System.out.println(" J J  A     A   V    A     A");
  }
}
